# Tsukuyomi Watch: The Samurai's Celestial Guide

A samurai-themed celestial guide: stargazing spot finder, space event tracker, and faithful astrophotography restoration platform.

---

## Overview

**Tsukuyomi Watch** (*月読の見張り*) is a full-stack astronomical observation, stargazing telemetry, and physics-based astrophotography restoration platform inspired by traditional Edo-period Japanese celestial cartography (*Tenmonzu* / 天文図). Designed for amateur astronomers, night-sky photographers, and stargazers, it combines real-time geospatial sanctuary discovery, orbital mechanics pass prediction, atmospheric weather scoring, and strictly non-generative deconvolution into a cohesive four-chapter experience.

---

## Features

### The Four Core Components

1. **01. The Watchtower (見張台) — Stargazing Location Finder & Celestial Dome** (`src/components/WatchtowerSection.tsx`, `src/components/CelestialMapWidget.tsx`)
   - **Real GPS & Geocoding Discovery**: Acquires user coordinates via the browser Geolocation API (with IP geolocation and Open-Meteo city/mountain search fallbacks) and reverse-geocodes place names via OpenStreetMap Nominatim.
   - **Live Overpass Sanctuary Search**: Queries OpenStreetMap Overpass API within a configurable radius (`10`, `25`, `50`, or `100 km`) for mountain peaks, scenic viewpoints, dark-sky parks, nature reserves, shrines, campsites, and astronomical observatories.
   - **Batched Atmospheric Scoring**: Fetches tonight's hourly cloud cover, relative humidity, and optical visibility in a single batched Open-Meteo Forecast API request, computes each site's **Night Honor Score (0–100)** and **Estimated Bortle class (1–9)**, and renders an interactive Leaflet map alongside a calibrated D3.js azimuthal celestial dome (`CelestialMapWidget.tsx`).

2. **02. The Celestial Scroll (天体巻物) — Space Event Tracker & Orbital Pass Predictor** (`src/components/CelestialScrollSection.tsx`, `server.ts`)
   - **2026–2027 Astronomical Catalog**: Tracks meteor showers, lunar/solar eclipses, planetary conjunctions, supermoons, and equinoxes/solstices (`src/data/celestialEvents2026_2027.json`) with local-timezone formatting and observer-latitude visibility filtering.
   - **Real SGP4 ISS Pass Prediction (`GET /api/iss-passes`)**: Downloads the latest NORAD 25544 TLE from CelesTrak (cached for 6 hours) and propagates passes over the next 5 days using `satellite.js` and `SunCalc`, keeping only passes where maximum elevation exceeds $20^\circ$, the ISS is sunlit, and the observer is in civil/nautical darkness (solar elevation $< -6^\circ$). Also displays live sub-satellite coordinates and ground track from `wheretheiss.at`.
   - **Live Rocket Launch Feed**: Pulls upcoming orbital missions from Launch Library 2 (`ll.thespacedevs.com`) with automatic fallback to Spaceflight News API.
   - **Tonight's Moonrise/Moonset Banner & Scheduled Alerts**: Displays an immediate top banner calculated via `SunCalc` for the user's coordinates (*"The Moon Rises/Sets Tonight at ..."* with phase name and illumination), and runs a 60-second background check that triggers browser `Notification` + in-app toast alerts when a subscribed event is within 30 minutes of start time.

3. **03. The Spirit Lens (霊鏡) — Faithful Astrophotography Restoration** (`src/components/SpiritLensSection.tsx`, `src/server/astroRestoration.ts`)
   - **Physics-Based Wavefront Restoration (`POST /api/restore`)**: Restores uploaded telescope captures or public-domain NASA/ESA presets (*Pillars of Creation*, *Carina Nebula*, *Andromeda Galaxy M31*) using stationary À Trous wavelet + patch Non-Local Means (NLM) denoising and damped Richardson-Lucy Gaussian PSF deconvolution.
   - **Automatic Pre-Processing & Safeguards**: Automatically downscales uploaded images with `sharp` so the longest side is at most `2048 px` before processing and enforces a 60-second server/client timeout with friendly error handling.
   - **Quantitative Source Detection & Faithfulness Report**: Extracts stars and galaxies (`DAOStarFinder` matched filtering + `SEP` second-moment ellipse segmentation) on both the original and restored frames and presents a **Faithfulness Report** card auditing total pixel flux conservation ($\Delta < 1\%$), original vs. restored object counts (*"No objects added"* check within $\le 2\%$), wavelet noise $\sigma$ reduction, and empirical PSF FWHM in pixels.

4. **04. The Dojo (道場) — Split-Screen Inspection & Reference Sky Survey** (`src/components/DojoDashboardSection.tsx`)
   - **Interactive Before/After Split-Slider**: Drag-handle comparator with synchronized 100%–300% zoom, pan, and selectable detected-object overlays (`All`, `Stars Only`, `Galaxies Only`).
   - **Real Reference Telescope Comparison**: Resolves target RA/Dec via CDS Sesame (Simbad/VizieR) and fetches real optical Digitized Sky Survey (`DSS2 Red`) cutouts from **NASA SkyView**, alongside curated NASA/ESA Hubble & JWST archival plates.
   - **Astrometric & Photometric Export**: One-click export of the restored PNG and detected object catalog (CSV or JSON).

### Bonus Features

- **Way of the Stargazer — Honor Points & Rank Progression** (`src/components/HonorPointsSection.tsx`, `src/utils/honorSystem.ts`): Gamified progression across 5 ranks (*Ronin* → *Ashigaru* → *Samurai* → *Hatamoto* → *Star Shogun*) persisted in `localStorage` with a 7-day observation streak and anti-spam verification.
- **Real-Time Lunar Phase HUD** (`src/components/common/DynamicMoonPhase.tsx`, `src/utils/lunarCycle.ts`, `GET /api/moon-phase`): Live SVG lunar phase disc in the Navbar and Hero combining `SunCalc` orbital mechanics with the US Naval Observatory (USNO) Astronomical Applications API.
- **Celestial Wisdom & Star Folklore** (`src/components/common/CelestialFactOfTheDay.tsx`, `src/data/celestialFactsAndFolklore.json`): Daily astrophysical fact paired with traditional Japanese star lore (*Tanabata*, *Subaru*, *Tsukuyomi-no-Mikoto*).
- **Procedural Tsukuyomi Soundscapes** (`src/utils/soundEngine.ts`): Pure Web Audio API synthesizer generating pentatonic koto plucks, suzu shrine chimes, temple bells, rain, digital wind, and moonlit night ambience with zero external audio files.

---

## Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Vite, D3.js (`d3` for the azimuthal star chart), Leaflet (`leaflet` for interactive terrestrial maps), Lucide React icons.
- **Backend**: Node.js, Express (`server.ts`), Multer (multipart image uploads), Sharp (`sharp` for high-speed image decoding, 2048 px downscaling, and raw pixel buffer extraction).
- **Astronomical & Orbital Computing**: `suncalc` (solar/lunar topocentric ephemeris), `satellite.js` (NORAD SGP4/SDP4 orbital propagation and solar shadow fraction).

---

## Data Sources and APIs

| Source / API | Endpoint / Library | Usage in Tsukuyomi Watch |
| :--- | :--- | :--- |
| **Open-Meteo** | `api.open-meteo.com/v1/forecast` & `geocoding-api.open-meteo.com/v1/search` | Batched hourly cloud cover, relative humidity, and optical visibility forecasts for candidate stargazing spots; city/peak geocoding search. |
| **Overpass / OpenStreetMap** | `overpass-api.de/api/interpreter` (fallback: `overpass.kumi.systems`) | Real-time geospatial discovery of nearby peaks, viewpoints, parks, nature reserves, shrines, observatories, and nearby towns/cities. |
| **Nominatim** | `nominatim.openstreetmap.org/reverse` | Reverse geocoding of browser GPS coordinates into human-readable locality labels. |
| **SunCalc** | `suncalc` (client & server) + USNO API (`aa.usno.navy.mil`) | Real-time lunar phase fraction, illumination percentage, moonrise/moonset times, and twilight sun depression filtering ($< -6^\circ$) for ISS passes. |
| **Launch Library 2** | `ll.thespacedevs.com/2.2.0/launch/upcoming/` | Upcoming global rocket launches, launch pad coordinates, and mission descriptions (with Spaceflight News API fallback). |
| **wheretheiss.at** | `api.wheretheiss.at/v1/satellites/25544` | Real-time ISS sub-satellite latitude, longitude, altitude (km), and orbital velocity (km/h). |
| **CelesTrak** | `celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=tle` | Authoritative ISS Two-Line Element (TLE) sets cached for 6 hours on the server and propagated with `satellite.js` for 5-day visible pass predictions. |
| **NASA SkyView** | `skyview.gsfc.nasa.gov/current/cgi/runquery.pl` | Real Digitized Sky Survey (`DSS2 Red`) telescope reference cutouts in the Dojo Dashboard (paired with CDS Sesame `cds.unistra.fr` coordinate lookup). |

---

## How the Night Honor Score is Calculated

Each candidate stargazing sanctuary in **The Watchtower** (`calculateNightHonorScore` in `src/components/WatchtowerSection.tsx`) is graded on a **0 to 100** scale starting from a base score of **100** and subtracting weighted atmospheric and light-pollution penalties over the local night window (`20:00`–`04:00`):

$$\text{Night Honor Score} = \text{clamp}_{[0,\,100]}\!\Big(\text{round}\big(100 - P_{\text{cloud}} - P_{\text{humidity}} - P_{\text{visibility}} - P_{\text{light}}\big)\Big)$$

### Penalty Weights & Formulas

1. **Cloud Cover Penalty ($P_{\text{cloud}}$ — weight $0.6\times$, max $60.0\text{ pts}$)**:
   $$P_{\text{cloud}} = 0.6 \times \text{CloudCover}_{\%}$$
2. **Humidity Penalty ($P_{\text{humidity}}$ — weight $0.25\times$ above $45\%$ RH, max $13.8\text{ pts}$)**:
   $$P_{\text{humidity}} = \max\!\big(0,\; (\text{Humidity}_{\%} - 45) \times 0.25\big)$$
3. **Optical Visibility Penalty ($P_{\text{visibility}}$ — weight $0.5\times$ below $24\text{ km}$, max $12.0\text{ pts}$)**:
   $$P_{\text{visibility}} = \max\!\big(0,\; (24 - \min(24, \text{Visibility}_{\text{km}})) \times 0.5\big)$$
4. **Light Pollution Penalty ($P_{\text{light}}$ — weight $2.5\text{ pts}$ per Bortle step above Class 1, max $20.0\text{ pts}$)**:
   $$P_{\text{light}} = (\text{EstimatedBortleClass} - 1) \times 2.5$$

When ranking candidate spots in the Watchtower sidebar, a **blended rank score** combines the Night Honor Score with a proximity term so closer dark-sky sites win ties:
$$\text{BlendedRankScore} = \text{NightHonorScore} - 12 \times \left(\frac{\text{DistanceFromUser}_{\text{km}}}{\text{SearchRadius}_{\text{km}}}\right)$$

---

## How Light Pollution is Estimated

> **Important Note**: The Bortle rating shown in the Watchtower UI (**"Estimated Bortle class"**) is a **heuristic estimate derived from the Haversine distance to nearby towns and cities** returned by OpenStreetMap Overpass, adjusted for urban population tier and site elevation—not a direct satellite radiance or Sky Quality Meter (SQM) measurement.

Specifically (`estimateBortleFromTownDistance` in `src/components/WatchtowerSection.tsx`):
1. The app queries Overpass for `node["place"~"city|town"]` within $60\text{ km}$ and finds the nearest settlement to each candidate stargazing spot ($d_{\text{town}}$ in km) along with its population tag.
2. It computes an effective dark-sky separation distance:
   $$d_{\text{eff}} = d_{\text{town}} \times f_{\text{pop}} + \max\!\left(0,\; \frac{\text{Elevation}_{\text{m}} - 350}{250}\right)$$
   where $f_{\text{pop}} = 0.72$ for cities $> 500{,}000$, $0.85$ for cities $> 100{,}000$, and $1.0$ for smaller towns.
3. $d_{\text{eff}}$ is mapped to **Estimated Bortle class 1–9** ($d_{\text{eff}} \ge 42\text{ km} \rightarrow \text{Class 1}$ down to $d_{\text{eff}} < 0.8\text{ km} \rightarrow \text{Class 9}$).

---

## Why the Image Restoration Is Faithful

In scientific astrophotography, **generative AI models (such as diffusion models, GANs, or neural super-resolution networks) must never be used**, because they synthesize plausible-looking textures learned from training datasets rather than recovering true incident photons. Any invented star, altered galaxy morphology, or hallucinated dust filament invalidates astrometric and photometric measurements.

The **Spirit Lens** pipeline (`POST /api/restore`, implemented in `src/server/astroRestoration.ts`) uses **strictly deterministic, physics-based signal processing and inverse-problem mathematics** with zero generative AI:

### 1. Multi-Scale À Trous Wavelet (Starlet) & Non-Local Means (NLM) Denoising
- **Noise Estimation via Median Absolute Deviation (MAD)**: The pipeline decomposes each color channel into dyadic wavelet planes $W_1, W_2$ and estimates the sensor read/shot noise standard deviation $\sigma_{\text{noise}} = \text{MAD}(W_1) / 0.6745$ directly from the finest wavelet scale.
- **Wavelet Soft-Thresholding & Non-Local Means**: High-frequency pixel fluctuations below the $k\sigma_{\text{noise}}$ significance threshold are attenuated, followed by a patch-weighted Non-Local Means (NLM) pass on low-SNR sky background regions while leaving high-SNR stellar cores untouched.
- **Why it is faithful**: Every output pixel is a weighted linear/convex combination of actual neighboring measurements from the same exposure; no external prior or synthetic texture is introduced.

### 2. Damped Richardson-Lucy (RL) Deconvolution with an Empirical Gaussian PSF
- **Empirical Point-Spread Function (PSF) Estimation**: Rather than guessing an arbitrary blur filter, the pipeline locates isolated, unsaturated stellar point sources across the frame, measures their second-order spatial central moments ($\mu_{20}, \mu_{02}$), and computes the median Full Width at Half Maximum ($\text{FWHM} = 2.3548\,\sigma_{\text{PSF}}$) caused by atmospheric seeing and telescope diffraction.
- **Flux-Conserving Maximum-Likelihood Deconvolution**: Using the estimated symmetric Gaussian PSF $P(x, y)$, the pipeline iterates the damped Richardson-Lucy update equation derived from Poisson photon statistics:
  $$u^{(t+1)} = u^{(t)} \cdot \left( \frac{I}{u^{(t)} * P} * P^T \right)$$
- **Why it is faithful**:
  1. **Strict Photon Flux Conservation**: At every iteration $t$, the total integrated flux $\sum_{x,y} u^{(t)}(x,y)$ is mathematically conserved and normalized to match the measured input flux $\sum_{x,y} I(x,y)$ within $< 1\%$.
  2. **Positivity Constraint**: If $u^{(0)}(x,y) \ge 0$, every subsequent iterate remains strictly non-negative.
  3. **Damped Background Regularization (White 1994)**: A signal-to-noise damping threshold prevents noise amplification ("speckle ringing") in empty sky background regions while sharpening real point sources back toward their diffraction-limited centroids.

### 3. Quantitative Source Extraction (`DAOStarFinder` + `SEP` Contour Moments)
- **Stars (`type: 'star'`)**: Identified via matched Gaussian filtering, local peak finding above $3.2\sigma_{\text{bg}}$, and `DAOStarFinder` sharpness criteria.
- **Galaxies / Extended Sources (`type: 'galaxy'`)**: Identified via connected-component contour segmentation above $2.0\sigma_{\text{bg}}$ and classified using second-order spatial covariance moments (semi-major axis $a$, semi-minor axis $b$, elongation $a/b$, and FWHM).
- **Photometric & Astrometric Output**: Computes detection on both the original and restored frames and returns sub-pixel flux-weighted centroid coordinates $(x, y)$, peak flux, integrated aperture flux, FWHM (in pixels), equivalent circular radius (in pixels), and the **Faithfulness Report** verifying that total flux is conserved ($< 1\%$ difference) and no spurious objects are added ($\le 2\%$ delta).

---

## Setup

### Prerequisites
- **Node.js** v20+ (or Bun)
- **npm** v9+

### Installation & Local Development

```bash
# 1. Install dependencies
npm install

# 2. Start the full-stack Express + Vite development server on port 3000
npm run dev
```

Additional scripts:
- `npm run build` — Builds the production frontend bundle into `dist/`.
- `npm run lint` — Runs `tsc --noEmit` to type-check the entire project.
- `npm start` — Starts the production server via `node server.ts`.

### Required Environment Variables

Copy `.env.example` to `.env` if needed. No paid API keys or external secrets are required to run any feature of the application:

| Variable | Required | Default | Description |
| :--- | :--- | :--- | :--- |
| `PORT` | Optional | `3000` | Port on which the Express + Vite server listens. |
| `APP_URL` | Optional | `http://localhost:3000` | Public URL of the hosted application (automatically injected in Cloud Run / AI Studio). |

---

## Known Limitations

1. **Heuristic Light Pollution Grading**: The Watchtower's `"Estimated Bortle class"` is computed from Haversine distance to OpenStreetMap `city`/`town` nodes and elevation rather than satellite night-radiance tiles (VIIRS/DMSP). Isolated industrial facilities not tagged as towns in OSM may have higher local skyglow than estimated.
2. **Public Overpass & USNO Rate Limits**: Public Overpass API instances (`overpass-api.de`, `overpass.kumi.systems`) and the US Naval Observatory API can occasionally experience high traffic; the app mitigates this with automatic failover, 10-minute session caching, and `SunCalc` local ephemeris fallbacks.
3. **Working Resolution Cap for Real-Time CPU Deconvolution**: Uploaded images larger than `2048 px` on their longest side are automatically downscaled with `sharp` before processing, and pixel deconvolution runs on a normalized working grid with a 60-second server timeout so multi-iteration Richardson-Lucy and Non-Local Means complete interactively in pure TypeScript without requiring a GPU.
4. **Browser Notification Constraints**: Scheduled 30-minute pre-event browser `Notification` alerts require the page to remain open in a tab and notification permission to be granted (in-app toasts always fire even if browser permission is denied or blocked by an iframe).

---

## Credits for NASA/ESA Images

The three astrophotography sample captures preloaded in **The Spirit Lens** and **The Dojo** (`public/assets/images/`) are public-domain observations courtesy of **NASA, ESA, CSA, and STScI**:

1. **Pillars of Creation (Hubble/JWST)** (`pillars_of_creation.jpg`) — *Credit: NASA, ESA, CSA, STScI; Joseph DePasquale (STScI), Anton M. Koekemoer (STScI), Alyssa Pagan (STScI).*
2. **Carina Nebula (JWST)** (`carina_nebula.jpg`) — *Credit: NASA, ESA, CSA, and STScI (James Webb Space Telescope NIRCam Cosmic Cliffs in NGC 3324).*
3. **Andromeda Galaxy (M31)** (`andromeda_m31.jpg`) — *Credit: NASA, ESA, JPL-Caltech, STScI (Galaxy Evolution Explorer / Hubble / Spitzer M31 mosaic).*

---

## Judging Checklist

| Problem Statement Requirement | Where It Is Implemented in the App |
| :--- | :--- |
| **1. Stargazing Spot Finder (GPS + Search + Radius + Real POIs)** | **The Watchtower** (`src/components/WatchtowerSection.tsx`): Browser Geolocation (`Use My Location`), IP & Open-Meteo geocoding search fallback, `10 / 25 / 50 / 100 km` radius selector, live Overpass API query for peaks/viewpoints/parks/shrines/observatories, and interactive Leaflet map + D3 sky dome (`src/components/CelestialMapWidget.tsx`). |
| **2. Weather & Night Honor Score (0–100) + Estimated Bortle Class** | **The Watchtower** (`src/components/WatchtowerSection.tsx`): Batched Open-Meteo hourly forecast (`cloud_cover`, `relative_humidity_2m`, `visibility`), formula breakdown tooltip on every spot card, and `"Estimated Bortle class"` 1–9 scale bar. |
| **3. Space Event Tracker (Meteor Showers, Eclipses, Conjunctions, Launches)** | **The Celestial Scroll** (`src/components/CelestialScrollSection.tsx`, `src/data/celestialEvents2026_2027.json`): Filterable timeline of 2026–2027 events in local time, latitude visibility indicator, and live Launch Library 2 rocket launch feed. |
| **4. Real ISS Pass Predictions & Live Telemetry** | **Server & Celestial Scroll** (`GET /api/iss-passes` in `server.ts`, `src/components/CelestialScrollSection.tsx`): CelesTrak NORAD 25544 TLE (6h cache) + `satellite.js` 5-day pass propagation filtered for max elevation $> 20^\circ$, sunlit station, and dark observer sky ($< -6^\circ$ solar altitude via `SunCalc`), plus live `wheretheiss.at` tracker. |
| **5. Event Alerts & Tonight's Moonrise/Moonset Banner** | **The Celestial Scroll** (`src/components/CelestialScrollSection.tsx`): Immediate `SunCalc` Moonrise/Moonset top banner with phase & illumination, plus a 60-second scheduler that triggers browser `Notification` and in-app toasts 30 minutes before alerted events. |
| **6. Faithful Astrophotography Restoration (No Generative AI)** | **The Spirit Lens** (`POST /api/restore` in `server.ts`, `src/server/astroRestoration.ts`, `src/components/SpiritLensSection.tsx`): Stationary wavelet + Non-Local Means denoising, empirical Gaussian PSF estimation, and damped Richardson-Lucy deconvolution with 2048 px `sharp` downscaling and 60s timeout. |
| **7. Object Detection & Photometric Faithfulness Report** | **The Spirit Lens** (`src/components/SpiritLensSection.tsx`, `src/server/astroRestoration.ts`): `DAOStarFinder` + `SEP` star/galaxy detection on both original and restored images, interactive viewport markers, catalog table, and **Faithfulness Report** card (flux conservation $< 1\%$, *"No objects added"* check $\le 2\%$, noise $\sigma$ before/after, and PSF FWHM). |
| **8. Split-Screen Before/After & Reference Telescope Comparison** | **The Dojo** (`src/components/DojoDashboardSection.tsx`): Interactive split-slider with zoom/pan, NASA SkyView (`DSS2 Red`) + Simbad/VizieR reference survey lookup, and CSV/JSON/PNG export. |
| **9. Bonus: Honor Points, Lunar HUD, Star Lore & Soundscapes** | **Navbar & Sections** (`src/components/HonorPointsSection.tsx`, `src/components/common/DynamicMoonPhase.tsx`, `src/components/common/CelestialFactOfTheDay.tsx`, `src/utils/soundEngine.ts`): 5-rank samurai progression, live USNO/SunCalc moon phase HUD, daily astrophysics + Japanese folklore card, and Web Audio synthesizer. |
