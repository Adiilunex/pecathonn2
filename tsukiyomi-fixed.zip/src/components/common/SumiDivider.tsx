import React from 'react';

interface SumiDividerProps {
  label?: string;
  variant?: 'crimson' | 'gold' | 'cyan' | 'subtle';
  className?: string;
}

export const SumiDivider: React.FC<SumiDividerProps> = ({
  label,
  variant = 'gold',
  className = '',
}) => {
  const accentColor =
    variant === 'crimson' ? '#FF2E4C' :
    variant === 'cyan' ? '#2EE6D6' :
    variant === 'subtle' ? '#34343a' :
    '#F5C26B';

  return (
    <div className={`relative flex items-center justify-center my-6 w-full select-none ${className}`}>
      {/* Left side: Dashed mechanical line fading into brush glow */}
      <div 
        className="flex-1 h-[1px]"
        style={{
          background: `linear-gradient(to right, transparent, rgba(245, 194, 107, 0.15) 30%, ${accentColor} 100%)`,
        }}
      />

      {/* Center node: Diamond or label badge */}
      <div className="mx-3 flex items-center space-x-2 shrink-0">
        <span 
          className="inline-block w-1.5 h-1.5 rotate-45"
          style={{ backgroundColor: accentColor, boxShadow: `0 0 8px ${accentColor}` }}
        />
        {label && (
          <span className="font-mono text-[10px] tracking-[0.2em] uppercase font-bold text-[#e3e1e9] opacity-90 px-1">
            {label}
          </span>
        )}
        <span 
          className="inline-block w-1.5 h-1.5 rotate-45"
          style={{ backgroundColor: accentColor, boxShadow: `0 0 8px ${accentColor}` }}
        />
      </div>

      {/* Right side: Brush glow fading into transparent void */}
      <div 
        className="flex-1 h-[1px]"
        style={{
          background: `linear-gradient(to right, ${accentColor}, rgba(245, 194, 107, 0.15) 70%, transparent 100%)`,
        }}
      />
    </div>
  );
};
