import React from 'react';

interface HUDCornerProps {
  color?: 'gold' | 'crimson' | 'cyan';
  type?: 'cross' | 'bracket';
  position?: 'all' | 'top-corners' | 'diagonal';
  className?: string;
}

export const HUDCorner: React.FC<HUDCornerProps> = ({
  color = 'gold',
  type = 'cross',
  position = 'all',
  className = '',
}) => {
  const colorClass = 
    color === 'crimson' ? 'text-[#FF2E4C]' : 
    color === 'cyan' ? 'text-[#2EE6D6]' : 
    'text-[#F5C26B]';

  const marker = type === 'cross' ? '+' : '⌜';

  return (
    <div className={`pointer-events-none select-none ${className}`}>
      {(position === 'all' || position === 'top-corners' || position === 'diagonal') && (
        <span className={`absolute top-0 left-0 font-mono text-[10px] leading-none ${colorClass} opacity-80 -translate-x-[3px] -translate-y-[3px]`}>
          {type === 'bracket' ? '┌' : marker}
        </span>
      )}
      {(position === 'all' || position === 'top-corners') && (
        <span className={`absolute top-0 right-0 font-mono text-[10px] leading-none ${colorClass} opacity-80 translate-x-[3px] -translate-y-[3px]`}>
          {type === 'bracket' ? '┐' : marker}
        </span>
      )}
      {(position === 'all' || position === 'diagonal') && (
        <span className={`absolute bottom-0 right-0 font-mono text-[10px] leading-none ${colorClass} opacity-80 translate-x-[3px] translate-y-[3px]`}>
          {type === 'bracket' ? '┘' : marker}
        </span>
      )}
      {position === 'all' && (
        <span className={`absolute bottom-0 left-0 font-mono text-[10px] leading-none ${colorClass} opacity-80 -translate-x-[3px] translate-y-[3px]`}>
          {type === 'bracket' ? '└' : marker}
        </span>
      )}
    </div>
  );
};
