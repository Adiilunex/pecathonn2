import React from 'react';

interface ToriiBeamProps {
  children?: React.ReactNode;
  subtitle?: string;
  badge?: string;
  compact?: boolean;
  className?: string;
}

export const ToriiBeam: React.FC<ToriiBeamProps> = ({
  children,
  subtitle,
  badge = 'SHRINE // SANCTUM 01',
  compact = false,
  className = '',
}) => {
  return (
    <div className={`relative w-full overflow-hidden ${className}`}>
      {/* Torii Top Crossbeam Structure (Kasagi & Shimaki) */}
      <div className="relative w-full flex flex-col items-center select-none">
        {/* Upper Beam: Emissive crimson with flared tips */}
        <div className="relative w-full max-w-5xl h-[3px] bg-[#FF2E4C] glow-torii">
          {/* Left flared tip */}
          <div className="absolute -left-3 -top-[4px] w-4 h-[3px] bg-[#FF2E4C] -rotate-12" />
          {/* Right flared tip */}
          <div className="absolute -right-3 -top-[4px] w-4 h-[3px] bg-[#FF2E4C] rotate-12" />
          
          {/* Center Gakuzuka plaque marker */}
          <div className="absolute left-1/2 -top-2 -translate-x-1/2 px-3 py-0.5 bg-[#07080D] border border-[#F5C26B] text-[#F5C26B] font-mono text-[9px] tracking-[0.25em] uppercase font-bold flex items-center space-x-1 shadow-[0_0_12px_rgba(245,194,107,0.3)]">
            <span className="w-1.5 h-1.5 bg-[#FF2E4C] animate-pulse" />
            <span>{badge}</span>
          </div>
        </div>

        {/* Lower Beam (Nuki) */}
        {!compact && (
          <div className="w-[92%] max-w-4xl h-[1px] bg-[#ad8887] opacity-40 mt-3" />
        )}
      </div>

      {/* Main Content Area framed between the pillars */}
      <div className="relative z-10 w-full mt-4">
        {children}
      </div>

      {subtitle && (
        <div className="w-full flex items-center justify-between text-[10px] font-mono tracking-widest text-[#ad8887] mt-3 px-2 border-t border-[#34343a]/40 pt-2">
          <span>// GATEWAY RESONANCE OK</span>
          <span>{subtitle}</span>
          <span>LAT: 35.6764°N</span>
        </div>
      )}
    </div>
  );
};
