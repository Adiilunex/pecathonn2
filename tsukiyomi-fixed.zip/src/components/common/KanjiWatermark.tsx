import React from 'react';

interface KanjiWatermarkProps {
  kanji: string;
  position?: 'top-right' | 'bottom-right' | 'center' | 'bottom-left' | 'top-left';
  opacity?: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const KanjiWatermark: React.FC<KanjiWatermarkProps> = ({
  kanji,
  position = 'top-right',
  opacity = 0.06,
  size = 'lg',
  className = '',
}) => {
  const positionClasses = {
    'top-right': 'top-2 right-4',
    'bottom-right': 'bottom-2 right-4',
    'center': 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2',
    'bottom-left': 'bottom-2 left-4',
    'top-left': 'top-2 left-4',
  }[position];

  const sizeClasses = {
    sm: 'text-6xl',
    md: 'text-8xl',
    lg: 'text-9xl',
    xl: 'text-[11rem]',
  }[size];

  return (
    <div
      aria-hidden="true"
      className={`absolute ${positionClasses} pointer-events-none select-none font-serif leading-none transition-opacity duration-700 ${sizeClasses} ${className}`}
      style={{
        opacity,
        fontFamily: "'Bodoni Moda', serif, 'Yu Mincho', 'Hiragino Mincho ProN', serif",
        color: '#F5C26B',
        textShadow: '0 0 40px rgba(245, 194, 107, 0.2)',
      }}
    >
      {kanji}
    </div>
  );
};
