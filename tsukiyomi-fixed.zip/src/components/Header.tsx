import React from 'react';
import { Volume2, VolumeX, Radio, Moon, Shield, Sparkles } from 'lucide-react';
import { playSuzuChime, isAudioEnabled, setAudioEnabled } from '../utils/soundEngine';

export type ScreenId = 'gateway' | 'schedule' | 'radar' | 'offerings' | 'pass';

interface HeaderProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  attunedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeScreen,
  onNavigate,
  attunedCount,
}) => {
  const [audioActive, setAudioActive] = React.useState(isAudioEnabled());

  const handleToggleSound = () => {
    const nextState = !audioActive;
    setAudioEnabled(nextState);
    setAudioActive(nextState);
    if (nextState) {
      playSuzuChime();
    }
  };

  const navItems: { id: ScreenId; label: string; kanji: string }[] = [
    { id: 'gateway', label: 'GATEWAY', kanji: '門' },
    { id: 'schedule', label: 'RITES', kanji: '祭' },
    { id: 'radar', label: 'RADAR', kanji: '鏡' },
    { id: 'offerings', label: 'SANCTUARY', kanji: '祈' },
    { id: 'pass', label: 'PASS', kanji: '札' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-[#07080D]/90 backdrop-blur-md border-b border-[#F5C26B]/20">
      {/* Topmost Tactical Telemetry Ribbon */}
      <div className="w-full bg-[#0D0E15] px-4 py-1 text-[10px] font-mono tracking-[0.16em] text-[#ad8887] border-b border-[#34343a]/50 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="flex items-center text-[#FF2E4C] font-bold">
            <span className="w-1.5 h-1.5 bg-[#FF2E4C] mr-1.5 animate-ping" />
            LIVE TELEMETRY
          </span>
          <span className="hidden sm:inline text-[#5d3f3f]">|</span>
          <span className="hidden sm:inline flex items-center text-[#2EE6D6]">
            <Radio className="w-3 h-3 mr-1 text-[#2EE6D6]" />
            FREQ: 432.8 MHz // STABLE
          </span>
          <span className="hidden md:inline text-[#5d3f3f]">|</span>
          <span className="hidden md:inline flex items-center text-[#F5C26B]">
            <Moon className="w-3 h-3 mr-1 text-[#F5C26B]" />
            MOON: 94.2% WAXING GIBBOUS
          </span>
        </div>

        <div className="flex items-center space-x-3">
          <span className="hidden sm:inline text-[#e3e1e9]/60">EPOCH: REIWA 08</span>
          <button
            onClick={handleToggleSound}
            aria-label={audioActive ? 'Mute ceremonial audio' : 'Unmute ceremonial audio'}
            className="flex items-center space-x-1.5 px-2 py-0.5 bg-[#12141C] border border-[#F5C26B]/40 hover:border-[#FF2E4C] text-[#F5C26B] hover:text-[#FF2E4C] transition-colors cursor-pointer text-[10px]"
          >
            {audioActive ? (
              <>
                <Volume2 className="w-3 h-3 text-[#2EE6D6]" />
                <span className="hidden xs:inline">AUDIO ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3 h-3 text-[#ad8887]" />
                <span className="hidden xs:inline">AUDIO MUTED</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between">
        {/* Brand Identity */}
        <button
          onClick={() => {
            playSuzuChime();
            onNavigate('gateway');
          }}
          className="flex items-center space-x-2.5 text-left group cursor-pointer focus:outline-none"
        >
          {/* Crimson Torii Mark */}
          <div className="relative w-8 h-8 flex items-center justify-center bg-[#12141C] border border-[#FF2E4C] group-hover:glow-torii transition-all">
            <span className="text-[#FF2E4C] font-display text-xl font-bold leading-none">月</span>
            <span className="absolute -top-1 -right-1 w-1.5 h-1.5 bg-[#F5C26B]" />
          </div>

          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-[#e3e1e9] group-hover:text-[#FF2E4C] transition-colors">
                TSUKIYOMI
              </span>
              <span className="font-mono text-[9px] font-bold text-[#F5C26B] tracking-[0.2em] border border-[#F5C26B]/40 px-1 py-0.2">
                CYBER-MYSTIC
              </span>
            </div>
            <p className="font-mono text-[9px] text-[#ad8887] tracking-[0.12em] uppercase leading-none">
              Neo-Tokyo Celestial Sanctuary
            </p>
          </div>
        </button>

        {/* Navigation Tabs (Zero-Pill Discipline: Sharp monospaced segmented buttons) */}
        <nav className="flex items-center space-x-1 sm:space-x-2">
          {navItems.map((item) => {
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  playSuzuChime();
                  onNavigate(item.id);
                }}
                className={`relative px-2.5 sm:px-3.5 py-1.5 font-mono text-xs sm:text-sm font-bold tracking-[0.14em] transition-all cursor-pointer border ${
                  isActive
                    ? 'bg-[#1B1E2B] text-[#FF2E4C] border-[#FF2E4C] glow-torii-sm shadow-[inset_0_0_8px_rgba(255,46,76,0.2)]'
                    : 'bg-transparent text-[#e3e1e9]/70 border-transparent hover:border-[#F5C26B]/30 hover:text-[#F5C26B]'
                }`}
              >
                <span className="mr-1 text-[10px] opacity-70 text-[#F5C26B]">{item.kanji}</span>
                <span>{item.label}</span>
                {item.id === 'pass' && attunedCount > 0 && (
                  <span className="ml-1.5 px-1 py-0.2 bg-[#FF2E4C] text-[#07080D] text-[9px] font-bold leading-none">
                    {attunedCount}
                  </span>
                )}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#FF2E4C]" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
