import React, { useState, useEffect } from 'react';
import { ArrowDown, Moon } from 'lucide-react';
import { StarField } from './StarField';
import { CelestialFactOfTheDay } from './common/CelestialFactOfTheDay';
import { getLunarPhase, fetchMoonPhaseApiData, MoonPhaseApiResponse } from '../utils/lunarCycle';

interface HeroSectionProps {
  onEnterWatchtower: () => void;
  onScrollToStory: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onEnterWatchtower,
  onScrollToStory,
}) => {
  const [apiLunar, setApiLunar] = useState<MoonPhaseApiResponse | null>(null);

  useEffect(() => {
    fetchMoonPhaseApiData()
      .then((res) => setApiLunar(res))
      .catch(() => {
        // Fallback to SunCalc local ephemeris
      });
  }, []);

  const lunarInfo = getLunarPhase(new Date(), undefined, undefined, apiLunar);
  // Adjust Night Honor Score dynamically based on real-time lunar illumination (darker sky = higher deep-sky clarity)
  const honorScore = Math.max(64, Math.min(98, Math.round(96 - lunarInfo.illuminationPercent * 0.22)));
  const strokeDashoffset = 283 - (283 * honorScore) / 100; // circumference ~ 283 for r=45

  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex flex-col items-center justify-center pt-24 pb-16 px-4 sm:px-6 overflow-hidden"
    >
      {/* Layered Background: Rainy Autumn Temple Gate & Mountain Sky */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 scale-105"
        style={{
          backgroundImage: 'url(/assets/images/rainy_temple_gate.jpg)',
        }}
      />

      {/* Atmospheric Overlays: Deep Indigo Night-Sky Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0E1326]/85 to-[#0A0A0F]/90" />
      <div className="absolute inset-0 bg-radial from-transparent via-[#0A0A0F]/60 to-[#0A0A0F]/95" />

      {/* Procedurally Generated StarField with Mouse Parallax Offset */}
      <StarField />

      {/* Luminous Glowing Moon Disk in the Celestial Sky */}
      <div className="absolute top-16 left-1/2 -translate-x-1/2 w-48 sm:w-64 h-48 sm:h-64 rounded-full bg-gradient-to-br from-[#F4EFE3] via-[#D4A84B]/40 to-transparent opacity-25 blur-3xl pointer-events-none" />

      {/* Hero Content */}
      <div className="relative z-20 max-w-4xl mx-auto text-center space-y-8">
        {/* Calligraphy Tagline Ribbon */}
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-[#0E1326]/80 border border-[#D4A84B]/40 backdrop-blur-md shadow-[0_0_20px_rgba(212,168,75,0.2)]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#B3202A] animate-ping" />
          <span className="text-[11px] font-mono tracking-[0.25em] uppercase text-[#D4A84B] font-bold">
            月読の門 · CHAPTER ZERO: THE THRESHOLD
          </span>
        </div>

        {/* Big Display Heading & Subtitle */}
        <div className="space-y-3">
          <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-[#F4EFE3] text-glow-moon leading-[1.12]">
            Read the heavens <br />
            <span className="text-[#D4A84B] text-glow-gold">like a warrior.</span>
          </h1>

          <p className="font-sans text-sm sm:text-base lg:text-lg text-[#F4EFE3]/85 max-w-2xl mx-auto leading-relaxed font-light">
            Find the clearest skies, track celestial alignments, and restore deep-space cosmic light with AI.
          </p>
        </div>

        {/* Live Widget: TONIGHT'S NIGHT HONOR SCORE */}
        <div className="pt-2">
          <div className="inline-flex flex-col sm:flex-row items-center justify-center gap-6 bg-[#0E1326]/85 backdrop-blur-md border border-[#D4A84B]/40 p-5 sm:p-6 rounded-2xl shadow-[0_0_35px_rgba(212,168,75,0.2)]">
            {/* Score Ring */}
            <div className="relative w-28 h-28 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  className="stroke-[#151B38]"
                  strokeWidth="7"
                  fill="none"
                />
                {/* Active Gold & Crimson Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  className="stroke-[#D4A84B]"
                  strokeWidth="7"
                  strokeDasharray="283"
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  fill="none"
                  style={{
                    filter: 'drop-shadow(0 0 8px rgba(212,168,75,0.6))',
                  }}
                />
              </svg>

              {/* Center Score Numbers */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-mono text-3xl font-bold text-[#F4EFE3] tabular-nums">
                  {honorScore}
                </span>
                <span className="text-[9px] font-mono text-[#D4A84B] tracking-wider uppercase font-bold">
                  HONOR / 100
                </span>
              </div>
            </div>

            {/* Score Information & Moonrise Status */}
            <div className="text-center sm:text-left space-y-1.5 max-w-xs">
              <div className="flex items-center justify-center sm:justify-start space-x-2 text-xs font-mono text-[#D4A84B] font-bold">
                <Moon className="w-3.5 h-3.5 text-[#F4EFE3]" />
                <span>TONIGHT'S NIGHT HONOR SCORE</span>
              </div>

              <h4 className="font-serif text-lg font-bold text-[#F4EFE3]">
                {lunarInfo.englishName} · {lunarInfo.japaneseName} ({lunarInfo.illuminationExact}%)
              </h4>

              <p className="font-sans text-xs text-[#8E9BB5] leading-relaxed">
                Moonrise: <span className="text-[#F4EFE3] font-semibold">{lunarInfo.moonriseFormatted}</span> · Moonset: <span className="text-[#F4EFE3] font-semibold">{lunarInfo.moonsetFormatted}</span> · Orbital Distance <span className="text-[#D4A84B] font-mono">{lunarInfo.distanceKm.toLocaleString()} km</span>.
              </p>

              {/* Quick Environmental badges */}
              <div className="flex items-center justify-center sm:justify-start space-x-2 pt-1 text-[10px] font-mono text-[#8E9BB5] tabular-nums">
                <span className="px-2 py-0.5 rounded bg-[#151B38] text-[#D4A84B]">BORTLE 2</span>
                <span className="px-2 py-0.5 rounded bg-[#151B38] text-[#F4EFE3]">ALT: {lunarInfo.altitudeDeg}°</span>
                <span className="px-2 py-0.5 rounded bg-[#151B38] text-[#8E9BB5]">AZ: {lunarInfo.azimuthDeg}° {lunarInfo.compassDirection}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Celestial Fact of the Day Component (Static JSON Astronomical Events & Folklore) */}
        <CelestialFactOfTheDay />

        {/* Buttons: Enter the Watchtower ↗ & Scroll to explore ↓ */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onEnterWatchtower}
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-[#B3202A] hover:bg-[#c72732] text-[#F4EFE3] font-sans text-xs sm:text-sm font-bold tracking-widest uppercase transition-all glow-crimson hover:scale-105 cursor-pointer flex items-center justify-center space-x-2 shadow-[0_0_20px_rgba(179,32,42,0.4)]"
          >
            <span>Enter the Watchtower</span>
            <span>↗</span>
          </button>

          <button
            onClick={onScrollToStory}
            className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-[#0E1326] hover:bg-[#151B38] border border-[#D4A84B]/50 text-[#F4EFE3] font-sans text-xs sm:text-sm font-semibold tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-2 shadow-[0_0_15px_rgba(212,168,75,0.15)]"
          >
            <span>Scroll to explore</span>
            <ArrowDown className="w-4 h-4 text-[#D4A84B] animate-bounce" />
          </button>
        </div>
      </div>

      {/* Floating Scroll Indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 text-center">
        <span className="text-[10px] font-mono tracking-[0.2em] uppercase text-[#8E9BB5] opacity-75">
          DESCEND TO THE OBSERVATORY · 天文台
        </span>
      </div>
    </section>
  );
};
