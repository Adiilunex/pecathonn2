/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { LoadingScreen } from './components/LoadingScreen';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { WatchtowerSection } from './components/WatchtowerSection';
import { CelestialScrollSection } from './components/CelestialScrollSection';
import { SpiritLensSection, AstroRestorationResponse } from './components/SpiritLensSection';
import { DojoDashboardSection } from './components/DojoDashboardSection';
import { HonorPointsSection } from './components/HonorPointsSection';
import { Footer } from './components/Footer';
import { FallingLeaves } from './components/FallingLeaves';
import { saveRestoration, loadLatestRestoration } from './utils/imageStore';

export default function App() {
  const [_loadingComplete, setLoadingComplete] = useState(false);
  const [latestRestoration, setLatestRestoration] = useState<AstroRestorationResponse | null>(null);
  const [latestCaptureTitle, setLatestCaptureTitle] = useState<string>(
    'Pillars of Creation (Hubble/JWST)'
  );

  // Becomes true once we've checked IndexedDB for a previously saved restoration
  const [storageReady, setStorageReady] = useState(false);

  // Restore the last Spirit Lens result (images + detections) after a page reload
  useEffect(() => {
    let cancelled = false;
    loadLatestRestoration().then((rec) => {
      if (cancelled) return;
      if (rec) {
        setLatestRestoration(rec.result);
        setLatestCaptureTitle(rec.captureTitle);
      }
      setStorageReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const handleScrollToWatchtower = () => {
    const el = document.getElementById('watchtower');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToDojo = () => {
    const el = document.getElementById('dojo');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToHonor = () => {
    const el = document.getElementById('honor');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-[#F4EFE3] selection:bg-[#B3202A] selection:text-[#F4EFE3] overflow-x-hidden relative">
      {/* 1. Loading Screen with Moon Phase Filling Loader & Torii Gate Doors */}
      <LoadingScreen onLoadingComplete={() => setLoadingComplete(true)} />

      {/* Drifting Cherry Blossom Petals & Starlight */}
      <FallingLeaves density={22} />

      {/* Global Fixed Navbar with Moon Phase & Sound Toggle */}
      <Navbar onHonorClick={handleScrollToHonor} />

      {/* 2. Hero: The Threshold */}
      <HeroSection
        onEnterWatchtower={handleScrollToWatchtower}
        onScrollToStory={handleScrollToWatchtower}
      />

      {/* 3. Chapter 01: The Watchtower (Stargazing Location Finder) */}
      <WatchtowerSection />

      {/* 4. Chapter 02: The Celestial Scroll (Space Event Tracker) */}
      <CelestialScrollSection />

      {/* 5. Chapter 03: The Spirit Lens (Faithful Astrophotography Image Restoration) */}
      <SpiritLensSection
        onNavigateToDojo={handleScrollToDojo}
        storageReady={storageReady}
        initialRestoration={latestRestoration}
        initialCaptureTitle={latestCaptureTitle}
        onRestorationComplete={(result, title) => {
          setLatestRestoration(result);
          setLatestCaptureTitle(title);
          void saveRestoration(result, title);
        }}
      />

      {/* 6. Chapter 04: The Dojo Dashboard (Visualization & Before/After Slider) */}
      <DojoDashboardSection
        restorationResult={latestRestoration}
        captureTitle={latestCaptureTitle}
      />

      {/* 7. Bonus Section: Honor Points & Live SkyView */}
      <HonorPointsSection />

      {/* 8. Footer with Marquee & Astronomical Credits */}
      <Footer />
    </div>
  );
}
